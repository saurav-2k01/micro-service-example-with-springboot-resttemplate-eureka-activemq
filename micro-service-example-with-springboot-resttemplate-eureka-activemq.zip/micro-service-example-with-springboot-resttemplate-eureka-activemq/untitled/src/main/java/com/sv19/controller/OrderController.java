package com.sv19.controller;


import com.sv19.model.Order;
import com.sv19.services.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/orders")
public class OrderController {
    @Autowired
    OrderService orderService;


    @PostMapping("/place-order")
    public ResponseEntity<Order> placeOrder(@RequestBody Order order){
        Order order1 = orderService.placeOrder(order);
        return new ResponseEntity<>(order1, HttpStatus.CREATED);
    }
}
