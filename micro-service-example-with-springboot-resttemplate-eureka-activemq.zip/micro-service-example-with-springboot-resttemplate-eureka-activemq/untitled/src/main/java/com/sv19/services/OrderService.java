package com.sv19.services;

import com.sv19.model.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

@Service
public class OrderService {
    @Autowired
    JmsTemplate jmsTemplate;

    public Order placeOrder(Order order){
        System.out.println(order.getDescription());
        jmsTemplate.convertAndSend("orderQueue", order.getDescription());
        return order;
    }
}
