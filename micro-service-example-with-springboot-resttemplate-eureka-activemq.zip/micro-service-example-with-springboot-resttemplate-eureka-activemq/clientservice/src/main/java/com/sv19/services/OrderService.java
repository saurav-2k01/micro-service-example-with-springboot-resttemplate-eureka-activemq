package com.sv19.services;

import com.sv19.models.Order;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    @JmsListener(destination = "orderQueue")
    public void ProcessOrder(String message){
        System.out.println(message);
    }

}
